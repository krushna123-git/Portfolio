import { motion } from "framer-motion";

const stats = [
  {
    number: "3.7+",
    title: "Years Experience",
    icon: "🚀",
  },
  {
    number: "20+",
    title: "Dashboards Created",
    icon: "📊",
  },
  {
    number: "10M+",
    title: "Records Analyzed",
    icon: "📈",
  },
  {
    number: "20+",
    title: "Reports Delivered",
    icon: "⚡",
  },
];

export default function Stats() {
  return (
    <section
      id="stats"
      className="py-20 md:py-24 px-4 md:px-6 bg-slate-900"
    >
      <div className="max-w-7xl mx-auto">

        {/* Heading */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <p className="text-blue-400 uppercase tracking-[5px] mb-4">
            Achievements
          </p>

          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            Professional Highlights
          </h2>

          <p className="text-slate-400 max-w-3xl mx-auto">
            Delivering business intelligence solutions,
            dashboard automation and data-driven insights
            through Power BI, SQL Server and analytics.
          </p>
        </motion.div>

        {/* Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">

          {stats.map((item, index) => (
            <motion.div
              key={item.title}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{
                duration: 0.6,
                delay: index * 0.1,
              }}
              viewport={{ once: true }}
              whileHover={{
                scale: 1.08,
                y: -10,
              }}
              className="
                relative
                overflow-hidden
                bg-white/5
                backdrop-blur-xl
                border
                border-white/10
                rounded-3xl
                p-6 md:p-8
                text-center
                hover:border-blue-500
                hover:shadow-blue-500/20
                hover:shadow-2xl
                transition-all
                duration-500
              "
            >
              {/* Animated Background Glow */}
              <div
                className="
                  absolute
                  inset-0
                  bg-gradient-to-r
                  from-blue-500/10
                  via-cyan-500/10
                  to-purple-500/10
                  opacity-0
                  group-hover:opacity-100
                  transition
                  duration-500
                "
              />

              <div className="relative z-10">

                {/* Icon */}
                <motion.div
                  whileHover={{ rotate: 10, scale: 1.2 }}
                  className="text-4xl md:text-5xl mb-4"
                >
                  {item.icon}
                </motion.div>

                {/* Number */}
                <h3 className="text-4xl md:text-5xl font-bold text-blue-400 mb-3">
                  {item.number}
                </h3>

                {/* Title */}
                <p className="text-slate-300 text-sm md:text-base">
                  {item.title}
                </p>

              </div>
            </motion.div>
          ))}

        </div>

      </div>
    </section>
  );
}