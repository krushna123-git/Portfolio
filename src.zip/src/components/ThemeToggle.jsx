import { useEffect, useState } from "react";

export default function ThemeToggle() {
  const [dark, setDark] = useState(true);

  useEffect(() => {
    if (dark) {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
  }, [dark]);

  return (
    <button
      onClick={() => setDark(!dark)}
      className="
        fixed
        bottom-6
        left-6
        z-50
        px-4
        py-3
        rounded-full
        bg-blue-600
        text-white
        shadow-lg
      "
    >
      {dark ? "☀️" : "🌙"}
    </button>
  );
}